################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
C:/ti/c2000/C2000Ware_5_05_00_00/device_support/f2833x/headers/cmd/DSP2833x_Headers_nonBIOS.cmd \
../F28335.cmd 

ASM_SRCS += \
C:/ti/c2000/C2000Ware_5_05_00_00/device_support/f2833x/common/source/DSP2833x_ADC_cal.asm \
C:/ti/c2000/C2000Ware_5_05_00_00/device_support/f2833x/common/source/DSP2833x_CodeStartBranch.asm \
C:/ti/c2000/C2000Ware_5_05_00_00/device_support/f2833x/common/source/DSP2833x_usDelay.asm 

C_SRCS += \
C:/ti/c2000/C2000Ware_5_05_00_00/device_support/f2833x/common/source/DSP2833x_Adc.c \
../DSP2833x_CpuTimers.c \
C:/ti/c2000/C2000Ware_5_05_00_00/device_support/f2833x/common/source/DSP2833x_DefaultIsr.c \
../DSP2833x_EPwm.c \
C:/ti/c2000/C2000Ware_5_05_00_00/device_support/f2833x/headers/source/DSP2833x_GlobalVariableDefs.c \
../DSP2833x_MemCopy.c \
C:/ti/c2000/C2000Ware_5_05_00_00/device_support/f2833x/common/source/DSP2833x_PieCtrl.c \
C:/ti/c2000/C2000Ware_5_05_00_00/device_support/f2833x/common/source/DSP2833x_PieVect.c \
C:/ti/c2000/C2000Ware_5_05_00_00/device_support/f2833x/common/source/DSP2833x_SysCtrl.c \
../Example_2833xAdcSoc.c 

C_DEPS += \
./DSP2833x_Adc.d \
./DSP2833x_CpuTimers.d \
./DSP2833x_DefaultIsr.d \
./DSP2833x_EPwm.d \
./DSP2833x_GlobalVariableDefs.d \
./DSP2833x_MemCopy.d \
./DSP2833x_PieCtrl.d \
./DSP2833x_PieVect.d \
./DSP2833x_SysCtrl.d \
./Example_2833xAdcSoc.d 

OBJS += \
./DSP2833x_ADC_cal.obj \
./DSP2833x_Adc.obj \
./DSP2833x_CodeStartBranch.obj \
./DSP2833x_CpuTimers.obj \
./DSP2833x_DefaultIsr.obj \
./DSP2833x_EPwm.obj \
./DSP2833x_GlobalVariableDefs.obj \
./DSP2833x_MemCopy.obj \
./DSP2833x_PieCtrl.obj \
./DSP2833x_PieVect.obj \
./DSP2833x_SysCtrl.obj \
./DSP2833x_usDelay.obj \
./Example_2833xAdcSoc.obj 

ASM_DEPS += \
./DSP2833x_ADC_cal.d \
./DSP2833x_CodeStartBranch.d \
./DSP2833x_usDelay.d 

OBJS__QUOTED += \
"DSP2833x_ADC_cal.obj" \
"DSP2833x_Adc.obj" \
"DSP2833x_CodeStartBranch.obj" \
"DSP2833x_CpuTimers.obj" \
"DSP2833x_DefaultIsr.obj" \
"DSP2833x_EPwm.obj" \
"DSP2833x_GlobalVariableDefs.obj" \
"DSP2833x_MemCopy.obj" \
"DSP2833x_PieCtrl.obj" \
"DSP2833x_PieVect.obj" \
"DSP2833x_SysCtrl.obj" \
"DSP2833x_usDelay.obj" \
"Example_2833xAdcSoc.obj" 

C_DEPS__QUOTED += \
"DSP2833x_Adc.d" \
"DSP2833x_CpuTimers.d" \
"DSP2833x_DefaultIsr.d" \
"DSP2833x_EPwm.d" \
"DSP2833x_GlobalVariableDefs.d" \
"DSP2833x_MemCopy.d" \
"DSP2833x_PieCtrl.d" \
"DSP2833x_PieVect.d" \
"DSP2833x_SysCtrl.d" \
"Example_2833xAdcSoc.d" 

ASM_DEPS__QUOTED += \
"DSP2833x_ADC_cal.d" \
"DSP2833x_CodeStartBranch.d" \
"DSP2833x_usDelay.d" 

ASM_SRCS__QUOTED += \
"C:/ti/c2000/C2000Ware_5_05_00_00/device_support/f2833x/common/source/DSP2833x_ADC_cal.asm" \
"C:/ti/c2000/C2000Ware_5_05_00_00/device_support/f2833x/common/source/DSP2833x_CodeStartBranch.asm" \
"C:/ti/c2000/C2000Ware_5_05_00_00/device_support/f2833x/common/source/DSP2833x_usDelay.asm" 

C_SRCS__QUOTED += \
"C:/ti/c2000/C2000Ware_5_05_00_00/device_support/f2833x/common/source/DSP2833x_Adc.c" \
"../DSP2833x_CpuTimers.c" \
"C:/ti/c2000/C2000Ware_5_05_00_00/device_support/f2833x/common/source/DSP2833x_DefaultIsr.c" \
"../DSP2833x_EPwm.c" \
"C:/ti/c2000/C2000Ware_5_05_00_00/device_support/f2833x/headers/source/DSP2833x_GlobalVariableDefs.c" \
"../DSP2833x_MemCopy.c" \
"C:/ti/c2000/C2000Ware_5_05_00_00/device_support/f2833x/common/source/DSP2833x_PieCtrl.c" \
"C:/ti/c2000/C2000Ware_5_05_00_00/device_support/f2833x/common/source/DSP2833x_PieVect.c" \
"C:/ti/c2000/C2000Ware_5_05_00_00/device_support/f2833x/common/source/DSP2833x_SysCtrl.c" \
"../Example_2833xAdcSoc.c" 


