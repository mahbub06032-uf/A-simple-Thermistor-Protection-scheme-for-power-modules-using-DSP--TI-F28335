#include "DSP28x_Project.h"

//================ User settings ================
#define DSPCLK                   (150000000UL)
#define FS_SWITCH                (70000UL)
#define FS_MOD                   (5000UL)
#define EPWM_DB                  (35U)

#define PWM_DELAY_NS             (150U)

// 2.3V threshold on 3.3V full-scale ADC
// 12-bit threshold = 2854
// raw register threshold = 2854 << 4 = 45664
#define ADC0_RAW_SHUTDOWN_THRESHOLD   (3186U)

#define PWM_RESTART_DELAY_COUNT  (FS_MOD * 10UL)
#define ADC_STARTUP_IGNORE_COUNT (1000U)
//==============================================

#define PERIOD (DSPCLK / (2UL * FS_SWITCH))

#define NS_TO_COUNTS(ns) \
    ((Uint16)((((unsigned long long)(ns)) * ((unsigned long long)DSPCLK) + 500000000ULL) / 1000000000ULL))

#define PWM2_DELAY_COUNTS (NS_TO_COUNTS(PWM_DELAY_NS))

//============ Globals for CCS watch ============
volatile Uint16 gRawAdcResult      = 0;
volatile Uint16 gRawAdcThreshold   = ADC0_RAW_SHUTDOWN_THRESHOLD;

volatile float  gAdcVoltage        = 0.0f;
volatile float  gThresholdVoltage  = 2.3f;

volatile Uint16 gDelayCounts       = PWM2_DELAY_COUNTS;
volatile Uint16 gDelayNs           = PWM_DELAY_NS;

volatile Uint16 gEpwm1CmpA         = PERIOD / 2;
volatile Uint16 gEpwm2CmpA         = PERIOD / 2;

volatile Uint16 gPwmFaultActive    = 0;
volatile Uint32 gRestartCounter    = 0;
volatile Uint16 gStartupCounter    = 0;

volatile Uint16 gTripCondition     = 0;
volatile Uint32 gShutdownCalls     = 0;
volatile Uint32 gRestartCalls      = 0;

volatile short  TimerFlag          = 0;
//===============================================

static void SetupEPWMs(void);
static void ConfigureEPwm1(void);
static void ConfigureEPwm2(void);
static void common_epwm_complementary_setup(volatile struct EPWM_REGS *p);

static void InitAdcA0_F28335(void);
static Uint16 ReadAdcRawA0_F28335(void);

static void PWM_Shutdown(void);
static void PWM_Restart(void);

__interrupt void cpu_timer0_isr(void);

int main(void)
{
    InitSysCtrl();

    MemCopy(&RamfuncsLoadStart, &RamfuncsLoadEnd, &RamfuncsRunStart);
    InitFlash();

    DINT;
    InitPieCtrl();
    IER = 0x0000;
    IFR = 0x0000;
    InitPieVectTable();

    EALLOW;
    PieVectTable.TINT0 = &cpu_timer0_isr;
    EDIS;

    InitCpuTimers();
    ConfigCpuTimer(&CpuTimer0, 150, (1000000UL / FS_MOD));
    CpuTimer0Regs.TCR.all = 0x4000;

    IER |= M_INT1;
    PieCtrlRegs.PIEIER1.bit.INTx7 = 1;

    InitAdc();
    InitAdcA0_F28335();

    SetupEPWMs();

    EINT;
    ERTM;

    for(;;)
    {
        if(TimerFlag)
        {
            TimerFlag = 0;

            if(gPwmFaultActive == 0U)
            {
                EPwm1Regs.CMPA.half.CMPA = PERIOD / 2;
                EPwm2Regs.CMPA.half.CMPA = PERIOD / 2;
            }

            // Read raw ADC register directly
            gRawAdcResult = ReadAdcRawA0_F28335();

            // Convert only for debug display
            gAdcVoltage = ((float)gRawAdcResult * 3.3f) / 4095.0f;
            gThresholdVoltage = ((float)gRawAdcThreshold * 3.3f) / 4095.0f;

            if(gStartupCounter < ADC_STARTUP_IGNORE_COUNT)
            {
                gStartupCounter++;
                gTripCondition = 0U;
            }
            else
            {
                gTripCondition = ((gPwmFaultActive == 0U) &&
                                  (gRawAdcResult < gRawAdcThreshold)) ? 1U : 0U;

                if(gTripCondition == 1U)
                {
                    PWM_Shutdown();
                    gShutdownCalls++;
                    gPwmFaultActive = 1U;
                    gRestartCounter = 0U;
                }
            }

            if(gPwmFaultActive == 1U)
            {
                if(gRestartCounter < PWM_RESTART_DELAY_COUNT)
                {
                    gRestartCounter++;
                }
                else
                {
                    gRawAdcResult = ReadAdcRawA0_F28335();
                    gAdcVoltage = ((float)gRawAdcResult * 3.3f) / 4095.0f;

                    if(gRawAdcResult >= gRawAdcThreshold)
                    {
                        PWM_Restart();
                        gRestartCalls++;
                        gPwmFaultActive = 0U;
                        gRestartCounter = 0U;
                    }
                    else
                    {
                        gRestartCounter = 0U;
                    }
                }
            }
        }
    }
}

__interrupt void cpu_timer0_isr(void)
{
    CpuTimer0.InterruptCount++;
    TimerFlag = 1;
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}

static void InitAdcA0_F28335(void)
{
    EALLOW;

    AdcRegs.ADCTRL1.bit.ACQ_PS   = 6;
    AdcRegs.ADCTRL1.bit.CPS      = 0;
    AdcRegs.ADCTRL3.bit.ADCCLKPS = 3;

    AdcRegs.ADCTRL1.bit.SEQ_CASC = 1;
    AdcRegs.ADCTRL1.bit.CONT_RUN = 0;

    AdcRegs.ADCMAXCONV.all = 0x0000;
    AdcRegs.ADCCHSELSEQ1.bit.CONV00 = 0x0;   // ADCINA0

    AdcRegs.ADCTRL2.bit.EPWM_SOCA_SEQ1 = 0;
    AdcRegs.ADCTRL2.bit.INT_ENA_SEQ1   = 0;

    EDIS;

    DELAY_US(1000);
}

static Uint16 ReadAdcRawA0_F28335(void)
{
    AdcRegs.ADCTRL2.bit.RST_SEQ1 = 1;
    AdcRegs.ADCTRL2.bit.SOC_SEQ1 = 1;

    while(AdcRegs.ADCST.bit.INT_SEQ1 == 0)
    {
    }

    gRawAdcResult = AdcMirror.ADCRESULT0;
    AdcRegs.ADCST.bit.INT_SEQ1_CLR = 1;

    // Return raw left-justified ADC register value directly
    return AdcMirror.ADCRESULT0;
}

static void common_epwm_complementary_setup(volatile struct EPWM_REGS *p)
{
    p->TBPRD = PERIOD;
    p->TBCTR = 0;
    p->TBPHS.half.TBPHS = 0;

    p->TBCTL.bit.CTRMODE   = TB_COUNT_UPDOWN;
    p->TBCTL.bit.PHSEN     = TB_DISABLE;
    p->TBCTL.bit.HSPCLKDIV = TB_DIV1;
    p->TBCTL.bit.CLKDIV    = TB_DIV1;

    p->CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    p->CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    p->CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;
    p->CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;

    p->CMPA.half.CMPA = PERIOD / 2;
    p->CMPB = 0;

    p->AQCTLA.all = 0;
    p->AQCTLA.bit.CAU = AQ_CLEAR;
    p->AQCTLA.bit.CAD = AQ_SET;

    p->AQCTLB.all = 0;

    p->DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;
    p->DBCTL.bit.POLSEL   = DB_ACTV_HIC;
    p->DBCTL.bit.IN_MODE  = DBA_ALL;
    p->DBRED = EPWM_DB;
    p->DBFED = EPWM_DB;

    p->TZSEL.all = 0x0000;
    p->TZCTL.bit.TZA = TZ_FORCE_LO;
    p->TZCTL.bit.TZB = TZ_FORCE_LO;
    p->TZCLR.all = 0xFFFF;
}

static void SetupEPWMs(void)
{
    InitEPwm1Gpio();
    InitEPwm2Gpio();

    EALLOW;
    SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 0;
    EDIS;

    ConfigureEPwm1();
    ConfigureEPwm2();

    EALLOW;
    SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 1;
    EDIS;
}

static void ConfigureEPwm1(void)
{
    EALLOW;

    common_epwm_complementary_setup(&EPwm1Regs);

    EPwm1Regs.CMPA.half.CMPA = PERIOD / 2;
    EPwm1Regs.TBCTL.bit.PHSEN    = TB_DISABLE;
    EPwm1Regs.TBCTL.bit.SYNCOSEL = TB_CTR_ZERO;

    EDIS;
}

static void ConfigureEPwm2(void)
{
    EALLOW;

    common_epwm_complementary_setup(&EPwm2Regs);

    EPwm2Regs.DBCTL.bit.POLSEL = DB_ACTV_LOC;
    EPwm2Regs.CMPA.half.CMPA = PERIOD / 2;

    EPwm2Regs.TBCTL.bit.PHSEN    = TB_ENABLE;
    EPwm2Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_IN;
    EPwm2Regs.TBPHS.half.TBPHS   = PWM2_DELAY_COUNTS;

    EDIS;
}

static void PWM_Shutdown(void)
{
    EALLOW;
    EPwm1Regs.TZFRC.bit.OST = 1;
    EPwm2Regs.TZFRC.bit.OST = 1;
    EDIS;
}

static void PWM_Restart(void)
{
    EALLOW;

    EPwm1Regs.TZCLR.bit.OST = 1;
    EPwm1Regs.TZCLR.bit.INT = 1;

    EPwm2Regs.TZCLR.bit.OST = 1;
    EPwm2Regs.TZCLR.bit.INT = 1;

    EDIS;
}